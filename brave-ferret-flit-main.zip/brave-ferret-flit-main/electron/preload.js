window.addEventListener('DOMContentLoaded', () => {
  console.log('X SMART VISION Desktop Application Initialized');
});