import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { 
  ShieldCheck, 
  Users, 
  FolderKanban, 
  Package, 
  Receipt, 
  Calendar, 
  BarChart3, 
  Lock, 
  LayoutDashboard,
  AlertTriangle,
  UserCheck,
  Globe,
  Coins
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RoleName } from '@/types';

interface AppLayoutProps {
  children: React.ReactNode;
}

export const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const location = useLocation();
  const { currentRole, setCurrentRole, inventory, tasks, language, setLanguage, currency, setCurrency, t } = useApp();

  const lowStockCount = inventory.filter(i => i.quantity <= i.minThreshold).length;
  const pendingTasksCount = tasks.filter(t => t.status === 'scheduled' || t.status === 'in_progress').length;

  const navItems = [
    { label: t('dashboard'), path: '/', icon: LayoutDashboard },
    { label: t('clients'), path: '/clients', icon: Users },
    { label: t('projects'), path: '/projects', icon: FolderKanban },
    { label: t('inventory'), path: '/inventory', icon: Package, badge: lowStockCount ? `${lowStockCount} ${t('alert')}` : undefined },
    { label: t('invoices'), path: '/invoices', icon: Receipt },
    { label: t('schedule'), path: '/schedule', icon: Calendar, badge: pendingTasksCount ? `${pendingTasksCount}` : undefined },
    { label: t('reports'), path: '/reports', icon: BarChart3 },
    { label: t('permissions'), path: '/permissions', icon: Lock },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      {/* Sidebar navigation */}
      <aside className="w-full md:w-64 bg-slate-900 text-slate-100 flex-shrink-0 flex flex-col justify-between border-r border-slate-800">
        <div>
          {/* Logo Brand Header */}
          <div className="p-5 flex items-center space-x-3 rtl:space-x-reverse border-b border-slate-800 bg-slate-950/50">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 shrink-0">
              <ShieldCheck className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-wide text-white leading-tight">{t('appName')}</h1>
              <p className="text-xs text-cyan-400 font-medium tracking-wider uppercase">{t('appSubtitle')}</p>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="p-3 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
                    isActive 
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30' 
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <Icon className={`h-4 w-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <Badge variant="destructive" className="text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Role Switcher & System Status */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/40 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <UserCheck className="h-3.5 w-3.5 text-cyan-400" /> {t('activeRole')}:
            </span>
            <Badge variant="outline" className="border-cyan-500/40 text-cyan-300 bg-cyan-950/30 text-[11px]">
              {currentRole}
            </Badge>
          </div>
          <Select value={currentRole} onValueChange={(val: RoleName) => setCurrentRole(val)}>
            <SelectTrigger className="w-full bg-slate-800 border-slate-700 text-slate-200 text-xs h-9">
              <SelectValue placeholder="Select Role" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800 text-slate-200">
              <SelectItem value="Admin">{t('admin')}</SelectItem>
              <SelectItem value="Project Manager">{t('projectManager')}</SelectItem>
              <SelectItem value="Field Technician">{t('fieldTechnician')}</SelectItem>
              <SelectItem value="Billing Clerk">{t('billingClerk')}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-10 shadow-sm">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <h2 className="text-xl font-bold text-slate-800">
              {navItems.find(n => n.path === location.pathname)?.label || t('dashboard')}
            </h2>
          </div>

          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            {/* Currency Switcher */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrency(currency === 'EGP' ? 'USD' : 'EGP')}
              className="flex items-center gap-1.5 text-xs font-semibold border-slate-200 hover:bg-slate-100"
            >
              <Coins className="h-3.5 w-3.5 text-amber-600" />
              <span>{currency === 'EGP' ? (language === 'ar' ? 'ج.م (مصري)' : 'EGP') : 'USD ($)'}</span>
            </Button>

            {/* Language Switcher */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
              className="flex items-center gap-1.5 text-xs font-semibold border-slate-200 hover:bg-slate-100"
            >
              <Globe className="h-3.5 w-3.5 text-blue-600" />
              <span>{language === 'en' ? 'العربية' : 'English'}</span>
            </Button>

            {lowStockCount > 0 && (
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-xs font-medium animate-pulse">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <span>{lowStockCount} {t('lowStockAlert')}</span>
              </div>
            )}
            <div className="h-8 w-px bg-slate-200 hidden sm:block" />
            <div className="flex items-center space-x-3 rtl:space-x-reverse">
              <div className="h-9 w-9 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center font-bold text-blue-700 text-sm shrink-0">
                {currentRole.substring(0, 2).toUpperCase()}
              </div>
              <div className="hidden sm:block">
                <p className="text-xs font-semibold text-slate-800">{t('loggedInAs')} {currentRole}</p>
                <p className="text-[11px] text-slate-500">{t('installerHub')}</p>
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic Page Content */}
        <div className="p-6 max-w-7xl w-full mx-auto space-y-6">
          {children}
        </div>
      </main>
    </div>
  );
};