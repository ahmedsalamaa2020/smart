import { Language, Currency } from '@/types';

export const formatCurrency = (amount: number, language: Language, currency: Currency = 'EGP'): string => {
  const formattedNum = amount.toLocaleString(language === 'ar' ? 'ar-EG' : 'en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });

  if (currency === 'EGP') {
    return language === 'ar' ? `${formattedNum} ج.م` : `EGP ${formattedNum}`;
  }

  return language === 'ar' ? `${formattedNum} $` : `$${formattedNum}`;
};