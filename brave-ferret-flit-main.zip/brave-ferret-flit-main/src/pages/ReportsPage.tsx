import React from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { BarChart3, TrendingUp, Package } from 'lucide-react';

const ReportsPage = () => {
  const { projects, inventory, invoices, t, formatMoney } = useApp();

  // Data transformations
  const revenueData = [
    { month: 'Oct', revenue: 210000 },
    { month: 'Nov', revenue: 340000 },
    { month: 'Dec', revenue: 410000 },
    { month: 'Jan', revenue: 290000 },
    { month: 'Feb', revenue: invoices.reduce((s, i) => s + i.totalAmount, 0) },
  ];

  const projectStatusData = [
    { name: t('ongoing'), value: projects.filter(p => p.status === 'ongoing').length, color: '#3b82f6' },
    { name: t('pending'), value: projects.filter(p => p.status === 'pending').length, color: '#f59e0b' },
    { name: t('completed'), value: projects.filter(p => p.status === 'completed').length, color: '#10b981' },
  ];

  const inventoryCategoryData = [
    { name: t('securityCameras'), count: inventory.filter(i => i.category === 'cameras').reduce((s, i) => s + i.quantity, 0) },
    { name: t('dvrsNvrs'), count: inventory.filter(i => i.category === 'dvrs_nvrs').reduce((s, i) => s + i.quantity, 0) },
    { name: t('cablesWiring'), count: inventory.filter(i => i.category === 'cables').reduce((s, i) => s + i.quantity, 0) },
    { name: t('sensorsAlarms'), count: inventory.filter(i => i.category === 'sensors').reduce((s, i) => s + i.quantity, 0) },
    { name: t('powerAdapters'), count: inventory.filter(i => i.category === 'power').reduce((s, i) => s + i.quantity, 0) },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900">{t('analyticsTitle')}</h1>
        <p className="text-xs text-slate-500">{t('analyticsDesc')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Revenue Bar Chart */}
        <Card className="border-slate-200 shadow-2xs">
          <CardHeader>
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-600" /> {t('monthlyRevenueTrend')}
            </CardTitle>
            <CardDescription>{t('billingTotals')}</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueData}>
                <XAxis dataKey="month" stroke="#888888" fontSize={12} />
                <YAxis stroke="#888888" fontSize={12} />
                <Tooltip formatter={(value: number) => [formatMoney(value), 'Revenue']} />
                <Bar dataKey="revenue" fill="#2563eb" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Project Pipeline Breakdown */}
        <Card className="border-slate-200 shadow-2xs">
          <CardHeader>
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-blue-600" /> {t('projectStatusDist')}
            </CardTitle>
            <CardDescription>{t('activeVsPending')}</CardDescription>
          </CardHeader>
          <CardContent className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={projectStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {projectStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Inventory Hardware Volume */}
        <Card className="border-slate-200 shadow-2xs lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <Package className="h-4 w-4 text-cyan-600" /> {t('hardwareStockVolume')}
            </CardTitle>
            <CardDescription>{t('warehouseStoredQty')}</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={inventoryCategoryData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} />
                <YAxis stroke="#888888" fontSize={12} />
                <Tooltip />
                <Bar dataKey="count" fill="#0891b2" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ReportsPage;