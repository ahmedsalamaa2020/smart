import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Minus, AlertTriangle, Search } from 'lucide-react';
import { InventoryCategory } from '@/types';

const InventoryPage = () => {
  const { inventory, addInventoryItem, adjustStock, t, formatMoney } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    category: 'cameras' as InventoryCategory,
    quantity: 10,
    minThreshold: 5,
    unitPrice: 4500,
    supplier: '',
    location: '',
  });

  const categories = [
    { label: t('allCategories'), value: 'all' },
    { label: t('securityCameras'), value: 'cameras' },
    { label: t('dvrsNvrs'), value: 'dvrs_nvrs' },
    { label: t('cablesWiring'), value: 'cables' },
    { label: t('sensorsAlarms'), value: 'sensors' },
    { label: t('powerAdapters'), value: 'power' },
    { label: t('accessories'), value: 'accessories' },
  ];

  const filteredItems = inventory.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || item.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.sku) return;

    addInventoryItem(formData);
    setFormData({
      name: '',
      sku: '',
      category: 'cameras',
      quantity: 10,
      minThreshold: 5,
      unitPrice: 4500,
      supplier: '',
      location: '',
    });
    setIsDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-900">{t('inventoryTitle')}</h1>
          <p className="text-xs text-slate-500">{t('inventoryDesc')}</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-500 text-white font-medium">
              <Plus className="mr-1.5 h-4 w-4 rtl:ml-1.5 rtl:mr-0" /> {t('addStockItem')}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{t('addHardwareTitle')}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3 pt-2">
              <div className="space-y-1">
                <Label className="text-xs">{t('deviceName')} *</Label>
                <Input 
                  required 
                  placeholder="e.g. 4K Bullet Camera Outdoor IP67" 
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('skuCode')} *</Label>
                  <Input 
                    required 
                    placeholder="e.g. CAM-4K-OUT-01" 
                    value={formData.sku}
                    onChange={e => setFormData({ ...formData, sku: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('category')}</Label>
                  <Select 
                    value={formData.category} 
                    onValueChange={(val: InventoryCategory) => setFormData({ ...formData, category: val })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cameras">{t('securityCameras')}</SelectItem>
                      <SelectItem value="dvrs_nvrs">{t('dvrsNvrs')}</SelectItem>
                      <SelectItem value="cables">{t('cablesWiring')}</SelectItem>
                      <SelectItem value="sensors">{t('sensorsAlarms')}</SelectItem>
                      <SelectItem value="power">{t('powerAdapters')}</SelectItem>
                      <SelectItem value="accessories">{t('accessories')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('initialQty')}</Label>
                  <Input 
                    type="number" 
                    value={formData.quantity}
                    onChange={e => setFormData({ ...formData, quantity: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('minThreshold')}</Label>
                  <Input 
                    type="number" 
                    value={formData.minThreshold}
                    onChange={e => setFormData({ ...formData, minThreshold: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('unitPrice')}</Label>
                  <Input 
                    type="number" 
                    value={formData.unitPrice}
                    onChange={e => setFormData({ ...formData, unitPrice: Number(e.target.value) })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('supplierName')}</Label>
                  <Input 
                    placeholder="..." 
                    value={formData.supplier}
                    onChange={e => setFormData({ ...formData, supplier: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('warehouseLocation')}</Label>
                  <Input 
                    placeholder="e.g. Shelf A-2" 
                    value={formData.location}
                    onChange={e => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>
              </div>

              <DialogFooter className="pt-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>{t('cancel')}</Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-500">{t('saveItem')}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 rtl:right-3.5 rtl:left-auto h-4 w-4 text-slate-400" />
          <Input 
            placeholder={t('search')}
            className="pl-10 rtl:pr-10 rtl:pl-3 bg-white border-slate-200"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-full sm:w-56 bg-white border-slate-200 text-xs">
            <SelectValue placeholder="..." />
          </SelectTrigger>
          <SelectContent>
            {categories.map(cat => (
              <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Inventory Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredItems.map((item) => {
          const isLowStock = item.quantity <= item.minThreshold;
          return (
            <Card key={item.id} className={`border-slate-200 transition-all ${isLowStock ? 'border-amber-300 shadow-amber-100/50 bg-amber-50/20' : ''}`}>
              <CardHeader className="p-4 pb-2 space-y-1">
                <div className="flex justify-between items-start gap-2">
                  <Badge variant="outline" className="text-[10px] uppercase font-bold text-slate-600">
                    {item.category.replace('_', ' & ')}
                  </Badge>
                  {isLowStock && (
                    <Badge className="bg-amber-500 text-white text-[10px] flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" /> {t('reorderRequired')}
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-sm font-bold text-slate-900">{item.name}</CardTitle>
                <p className="text-[11px] text-slate-400 font-mono">SKU: {item.sku}</p>
              </CardHeader>

              <CardContent className="p-4 pt-2 space-y-4 text-xs text-slate-600">
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-semibold">{t('unitCost')}</span>
                    <span className="font-bold text-slate-800 text-sm">{formatMoney(item.unitPrice)}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block font-semibold">{t('storage')}</span>
                    <span className="font-medium text-slate-700 truncate block">{item.location || 'Main Shelf'}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-slate-100 pt-3">
                  <div>
                    <p className="text-xs font-semibold text-slate-700">{t('stockAvailable')}</p>
                    <p className="text-[11px] text-slate-400">{t('reorderAt')} &le; {item.minThreshold}</p>
                  </div>
                  
                  {/* Plus & Minus stock adjusters */}
                  <div className="flex items-center space-x-2 rtl:space-x-reverse bg-slate-100 p-1 rounded-lg border border-slate-200">
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="h-7 w-7 text-slate-700 hover:bg-white"
                      onClick={() => adjustStock(item.id, -1)}
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className={`font-bold px-2 ${isLowStock ? 'text-amber-600' : 'text-slate-900'}`}>
                      {item.quantity}
                    </span>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="h-7 w-7 text-slate-700 hover:bg-white"
                      onClick={() => adjustStock(item.id, 1)}
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default InventoryPage;