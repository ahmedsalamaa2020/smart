import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Plus, Building2, Phone, Mail, MapPin, Calendar, Trash2 } from 'lucide-react';
import { Client } from '@/types';

const ClientsPage = () => {
  const { clients, addClient, deleteClient, currentRole, t } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    companyName: '',
    email: '',
    phone: '',
    address: '',
    contractType: 'Standard' as Client['contractType'],
    contractEndDate: '',
    notes: '',
  });

  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.companyName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;
    addClient(formData);
    setFormData({
      name: '',
      companyName: '',
      email: '',
      phone: '',
      address: '',
      contractType: 'Standard',
      contractEndDate: '',
      notes: '',
    });
    setIsDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-900">{t('clientDirectory')}</h1>
          <p className="text-xs text-slate-500">{t('clientDirDesc')}</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-500 text-white font-medium">
              <Plus className="mr-1.5 h-4 w-4 rtl:ml-1.5 rtl:mr-0" /> {t('addNewClient')}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{t('registerClientTitle')}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3 pt-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('clientName')} *</Label>
                  <Input 
                    required 
                    placeholder="e.g. John Miller" 
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('companyName')}</Label>
                  <Input 
                    placeholder="e.g. Apex Security Inc" 
                    value={formData.companyName}
                    onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('email')} *</Label>
                  <Input 
                    required 
                    type="email" 
                    placeholder="client@company.com" 
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('phone')}</Label>
                  <Input 
                    placeholder="+1 (555) 000-0000" 
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">{t('facilityAddress')}</Label>
                <Input 
                  placeholder="Full street address" 
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('contractPlan')}</Label>
                  <Select 
                    value={formData.contractType} 
                    onValueChange={(val: Client['contractType']) => setFormData({ ...formData, contractType: val })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Standard">{t('standard')}</SelectItem>
                      <SelectItem value="Annual Maintenance">{t('annualMaintenance')}</SelectItem>
                      <SelectItem value="VIP Enterprise">{t('vipEnterprise')}</SelectItem>
                      <SelectItem value="On-Demand">{t('onDemand')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('contractExpiry')}</Label>
                  <Input 
                    type="date" 
                    value={formData.contractEndDate}
                    onChange={e => setFormData({ ...formData, contractEndDate: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">{t('techNotes')}</Label>
                <Textarea 
                  rows={3} 
                  placeholder="..."
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>

              <DialogFooter className="pt-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>{t('cancel')}</Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-500">{t('saveClient')}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3.5 top-3 rtl:right-3.5 rtl:left-auto h-4 w-4 text-slate-400" />
        <Input 
          placeholder={t('searchClientsPlaceholder')}
          className="pl-10 rtl:pr-10 rtl:pl-3 bg-white border-slate-200"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Clients Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredClients.map((client) => (
          <Card key={client.id} className="border-slate-200 hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between">
            <div className="p-5 space-y-4">
              <div className="flex justify-between items-start gap-2">
                <div>
                  <h3 className="font-bold text-slate-900 text-base">{client.name}</h3>
                  {client.companyName && (
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <Building2 className="h-3.5 w-3.5 text-slate-400" /> {client.companyName}
                    </p>
                  )}
                </div>
                <Badge variant="outline" className={`text-[11px] font-semibold ${
                  client.contractType === 'VIP Enterprise' ? 'bg-purple-50 text-purple-700 border-purple-300' :
                  client.contractType === 'Annual Maintenance' ? 'bg-blue-50 text-blue-700 border-blue-300' :
                  'bg-slate-100 text-slate-700 border-slate-200'
                }`}>
                  {client.contractType}
                </Badge>
              </div>

              <div className="space-y-2 text-xs text-slate-600">
                <p className="flex items-center gap-2">
                  <Mail className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">{client.email}</span>
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <span>{client.phone}</span>
                </p>
                <p className="flex items-start gap-2">
                  <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span className="line-clamp-2">{client.address}</span>
                </p>
                {client.contractEndDate && (
                  <p className="flex items-center gap-2 text-slate-500 font-medium">
                    <Calendar className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span>{t('contractExpiry')}: {client.contractEndDate}</span>
                  </p>
                )}
              </div>

              {client.notes && (
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs text-slate-600 italic">
                  "{client.notes}"
                </div>
              )}
            </div>

            <div className="p-3 bg-slate-50/80 border-t border-slate-100 flex justify-between items-center text-xs text-slate-400">
              <span>{t('addedOn')} {client.createdAt}</span>
              {currentRole === 'Admin' && (
                <Button 
                  size="icon" 
                  variant="ghost" 
                  className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-50" 
                  onClick={() => deleteClient(client.id)}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ClientsPage;