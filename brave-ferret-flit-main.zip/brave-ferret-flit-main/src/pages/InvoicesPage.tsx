import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Receipt, Plus, CheckCircle, AlertCircle, Clock, Trash2 } from 'lucide-react';
import { InvoiceItem, PaymentStatus } from '@/types';
import { toast } from 'sonner';

const InvoicesPage = () => {
  const { invoices, clients, projects, addInvoice, updateInvoiceStatus, t, formatMoney } = useApp();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form
  const [selectedClientId, setSelectedClientId] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([
    { description: 'Security Camera Hardware & Installation', quantity: 1, unitPrice: 35000, total: 35000 }
  ]);

  const addItemRow = () => {
    setItems(prev => [...prev, { description: '', quantity: 1, unitPrice: 0, total: 0 }]);
  };

  const updateItemRow = (index: number, field: keyof InvoiceItem, val: string | number) => {
    setItems(prev => prev.map((item, idx) => {
      if (idx === index) {
        const updated = { ...item, [field]: val };
        if (field === 'quantity' || field === 'unitPrice') {
          updated.total = Number(updated.quantity) * Number(updated.unitPrice);
        }
        return updated;
      }
      return item;
    }));
  };

  const removeItemRow = (index: number) => {
    setItems(prev => prev.filter((_, idx) => idx !== index));
  };

  const calculateSubtotal = () => items.reduce((sum, i) => sum + i.total, 0);
  const subtotal = calculateSubtotal();
  const tax = subtotal * 0.08; // 8% tax
  const totalAmount = subtotal + tax;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find(c => c.id === selectedClientId);
    if (!client || items.length === 0) {
      toast.error('Please select a client and add at least one line item');
      return;
    }

    addInvoice({
      clientId: client.id,
      clientName: client.name,
      projectId: selectedProjectId || undefined,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: dueDate || new Date(Date.now() + 30*24*60*60*1000).toISOString().split('T')[0],
      items,
      subtotal,
      tax,
      totalAmount,
      status: 'pending',
    });

    setIsDialogOpen(false);
    setSelectedClientId('');
    setSelectedProjectId('');
    setItems([{ description: 'Security Camera Hardware & Installation', quantity: 1, unitPrice: 35000, total: 35000 }]);
  };

  const getStatusBadge = (status: PaymentStatus) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-emerald-500 text-white"><CheckCircle className="h-3 w-3 mr-1" /> {t('paid')}</Badge>;
      case 'partially_paid':
        return <Badge className="bg-blue-500 text-white"><Clock className="h-3 w-3 mr-1" /> {t('partiallyPaid')}</Badge>;
      case 'overdue':
        return <Badge className="bg-red-500 text-white"><AlertCircle className="h-3 w-3 mr-1" /> {t('overdue')}</Badge>;
      default:
        return <Badge variant="outline" className="border-amber-300 text-amber-700 bg-amber-50"><Clock className="h-3 w-3 mr-1" /> {t('pending')}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-900">{t('invoicesTitle')}</h1>
          <p className="text-xs text-slate-500">{t('invoicesDesc')}</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-500 text-white font-medium">
              <Plus className="mr-1.5 h-4 w-4 rtl:ml-1.5 rtl:mr-0" /> {t('createInvoice')}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{t('issueInvoiceTitle')}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('selectClient')} *</Label>
                  <Select value={selectedClientId} onValueChange={setSelectedClientId}>
                    <SelectTrigger><SelectValue placeholder="..." /></SelectTrigger>
                    <SelectContent>
                      {clients.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs">{t('relatedProject')}</Label>
                  <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
                    <SelectTrigger><SelectValue placeholder="..." /></SelectTrigger>
                    <SelectContent>
                      {projects.map(p => (
                        <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">{t('paymentDueDate')}</Label>
                <Input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
              </div>

              {/* Line Items */}
              <div className="space-y-2 pt-2">
                <div className="flex justify-between items-center">
                  <Label className="text-xs font-bold text-slate-700">{t('lineItems')}</Label>
                  <Button type="button" size="sm" variant="outline" className="text-xs h-7" onClick={addItemRow}>{t('addRow')}</Button>
                </div>

                {items.map((item, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 items-center bg-slate-50 p-2 rounded border border-slate-200">
                    <Input 
                      placeholder="..." 
                      className="col-span-5 text-xs bg-white" 
                      value={item.description}
                      onChange={e => updateItemRow(index, 'description', e.target.value)}
                    />
                    <Input 
                      type="number" 
                      min={1} 
                      className="col-span-2 text-xs bg-white" 
                      value={item.quantity}
                      onChange={e => updateItemRow(index, 'quantity', Number(e.target.value))}
                    />
                    <Input 
                      type="number" 
                      className="col-span-3 text-xs bg-white" 
                      value={item.unitPrice}
                      onChange={e => updateItemRow(index, 'unitPrice', Number(e.target.value))}
                    />
                    <Button 
                      type="button" 
                      size="icon" 
                      variant="ghost" 
                      className="col-span-2 h-7 w-7 text-red-500" 
                      onClick={() => removeItemRow(index)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}

                <div className="text-right rtl:text-left text-xs space-y-1 pt-2">
                  <p className="text-slate-500">{t('subtotal')}: <strong className="text-slate-800">{formatMoney(subtotal)}</strong></p>
                  <p className="text-slate-500">{t('tax')}: <strong className="text-slate-800">{formatMoney(tax)}</strong></p>
                  <p className="text-sm font-bold text-blue-600">{t('total')}: {formatMoney(totalAmount)}</p>
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>{t('cancel')}</Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-500">{t('issueInvoiceBtn')}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Invoice List */}
      <div className="space-y-4">
        {invoices.map((inv) => (
          <Card key={inv.id} className="border-slate-200 shadow-2xs">
            <CardHeader className="p-4 pb-2 border-b border-slate-100 flex flex-col sm:flex-row justify-between sm:items-center gap-2">
              <div className="flex items-center gap-3">
                <Receipt className="h-5 w-5 text-blue-600" />
                <div>
                  <CardTitle className="text-sm font-bold text-slate-900">{inv.invoiceNumber}</CardTitle>
                  <CardDescription className="text-xs font-medium text-slate-500">{t('clients')}: {inv.clientName}</CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {getStatusBadge(inv.status)}
                <Select value={inv.status} onValueChange={(val: PaymentStatus) => updateInvoiceStatus(inv.id, val)}>
                  <SelectTrigger className="h-7 text-xs w-32 bg-white"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="paid">{t('paid')}</SelectItem>
                    <SelectItem value="partially_paid">{t('partiallyPaid')}</SelectItem>
                    <SelectItem value="pending">{t('pending')}</SelectItem>
                    <SelectItem value="overdue">{t('overdue')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>

            <CardContent className="p-4 space-y-3">
              <div className="space-y-1">
                {inv.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-xs text-slate-600">
                    <span>{item.description} (x{item.quantity})</span>
                    <span className="font-medium">{formatMoney(item.total)}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-xs">
                <span className="text-slate-400">{t('issuedOn')}: {inv.issueDate} • {t('dueOn')}: <strong className="text-slate-700">{inv.dueDate}</strong></span>
                <span className="text-sm font-extrabold text-slate-900">{t('total')}: {formatMoney(inv.totalAmount)}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default InvoicesPage;