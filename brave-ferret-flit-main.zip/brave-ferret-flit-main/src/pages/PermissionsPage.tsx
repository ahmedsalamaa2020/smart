import React from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck } from 'lucide-react';
import { RolePermission } from '@/types';

const PermissionsPage = () => {
  const { permissions, updatePermissions, currentRole, t } = useApp();

  const permissionModules: { key: keyof Omit<RolePermission, 'role'>; label: string; desc: string }[] = [
    { key: 'manageClients', label: t('clientMgmt'), desc: t('clientMgmtDesc') },
    { key: 'manageProjects', label: t('projectOps'), desc: t('projectOpsDesc') },
    { key: 'manageInventory', label: t('inventoryCtrl'), desc: t('inventoryCtrlDesc') },
    { key: 'manageInvoices', label: t('invoicesBilling'), desc: t('invoicesBillingDesc') },
    { key: 'manageSchedule', label: t('techScheduling'), desc: t('techSchedulingDesc') },
    { key: 'viewReports', label: t('analyticsReports'), desc: t('analyticsReportsDesc') },
    { key: 'managePermissions', label: t('permissionsSetup'), desc: t('permissionsSetupDesc') },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <h1 className="text-xl font-bold text-slate-900">{t('rbacTitle')}</h1>
        <p className="text-xs text-slate-500">{t('rbacDesc')}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {permissions.map((perm) => (
          <Card key={perm.role} className={`border-slate-200 shadow-2xs ${perm.role === currentRole ? 'border-cyan-500 ring-2 ring-cyan-500/20' : ''}`}>
            <CardHeader className="p-4 pb-2 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5 text-blue-600" /> {perm.role}
                </CardTitle>
                <CardDescription className="text-xs">
                  {perm.role === 'Admin' ? t('admin') :
                   perm.role === 'Project Manager' ? t('projectManager') :
                   perm.role === 'Field Technician' ? t('fieldTechnician') :
                   t('billingClerk')}
                </CardDescription>
              </div>
              {perm.role === currentRole && (
                <Badge className="bg-cyan-600 text-white text-[10px]">{t('activeRoleBadge')}</Badge>
              )}
            </CardHeader>

            <CardContent className="p-4 pt-3 space-y-3">
              {permissionModules.map((module) => (
                <div key={module.key} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <div className="space-y-0.5 max-w-[80%]">
                    <p className="text-xs font-semibold text-slate-800">{module.label}</p>
                    <p className="text-[11px] text-slate-400">{module.desc}</p>
                  </div>
                  <Switch 
                    checked={perm[module.key]} 
                    disabled={currentRole !== 'Admin'}
                    onCheckedChange={(val) => updatePermissions(perm.role, module.key, val)}
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default PermissionsPage;