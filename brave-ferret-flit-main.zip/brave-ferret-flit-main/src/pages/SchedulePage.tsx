import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Clock, MapPin, User } from 'lucide-react';
import { ScheduleTask, TaskPriority } from '@/types';

const SchedulePage = () => {
  const { tasks, clients, addTask, updateTaskStatus, t } = useApp();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form
  const [formData, setFormData] = useState({
    title: '',
    clientId: '',
    projectId: '',
    technicianName: '',
    scheduledDate: new Date().toISOString().split('T')[0],
    scheduledTime: '10:00 AM',
    type: 'Periodic Maintenance' as ScheduleTask['type'],
    priority: 'medium' as TaskPriority,
    notes: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find(c => c.id === formData.clientId);
    if (!formData.title || !client) return;

    addTask({
      title: formData.title,
      clientId: client.id,
      clientName: client.name,
      projectId: formData.projectId || undefined,
      technicianName: formData.technicianName || 'Field Tech',
      scheduledDate: formData.scheduledDate,
      scheduledTime: formData.scheduledTime,
      type: formData.type,
      status: 'scheduled',
      priority: formData.priority,
      notes: formData.notes,
      address: client.address,
    });

    setIsDialogOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-900">{t('taskScheduleTitle')}</h1>
          <p className="text-xs text-slate-500">{t('taskScheduleDesc')}</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-500 text-white font-medium">
              <Plus className="mr-1.5 h-4 w-4 rtl:ml-1.5 rtl:mr-0" /> {t('scheduleVisitBtn')}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{t('scheduleAppointmentTitle')}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3 pt-2">
              <div className="space-y-1">
                <Label className="text-xs">{t('taskTitle')} *</Label>
                <Input 
                  required 
                  placeholder="..." 
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('clientLocation')} *</Label>
                  <Select value={formData.clientId} onValueChange={val => setFormData({ ...formData, clientId: val })}>
                    <SelectTrigger><SelectValue placeholder="..." /></SelectTrigger>
                    <SelectContent>
                      {clients.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs">{t('assignedTech')}</Label>
                  <Input 
                    placeholder="Tech Name" 
                    value={formData.technicianName}
                    onChange={e => setFormData({ ...formData, technicianName: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('date')}</Label>
                  <Input 
                    type="date" 
                    value={formData.scheduledDate}
                    onChange={e => setFormData({ ...formData, scheduledDate: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('time')}</Label>
                  <Input 
                    placeholder="10:00 AM" 
                    value={formData.scheduledTime}
                    onChange={e => setFormData({ ...formData, scheduledTime: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('visitType')}</Label>
                  <Select value={formData.type} onValueChange={(val: ScheduleTask['type']) => setFormData({ ...formData, type: val })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Installation">{t('installation')}</SelectItem>
                      <SelectItem value="Periodic Maintenance">{t('periodicMaintenance')}</SelectItem>
                      <SelectItem value="Emergency Repair">{t('emergencyRepair')}</SelectItem>
                      <SelectItem value="Site Inspection">{t('siteInspection')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs">{t('priority')}</Label>
                  <Select value={formData.priority} onValueChange={(val: TaskPriority) => setFormData({ ...formData, priority: val })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">{t('low')}</SelectItem>
                      <SelectItem value="medium">{t('medium')}</SelectItem>
                      <SelectItem value="high">{t('high')}</SelectItem>
                      <SelectItem value="urgent">{t('urgent')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">{t('instructions')}</Label>
                <Textarea 
                  rows={3} 
                  placeholder="..." 
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>

              <DialogFooter className="pt-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>{t('cancel')}</Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-500">{t('confirmSchedule')}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Task List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {tasks.map((task) => (
          <Card key={task.id} className="border-slate-200 hover:shadow-md transition-shadow">
            <CardHeader className="p-4 pb-2 space-y-1">
              <div className="flex justify-between items-center">
                <Badge className={`text-[10px] uppercase font-bold ${
                  task.priority === 'urgent' ? 'bg-red-500 text-white' :
                  task.priority === 'high' ? 'bg-amber-500 text-white' :
                  'bg-slate-200 text-slate-800'
                }`}>
                  {t(task.priority as any) || task.priority}
                </Badge>
                <Badge variant="outline" className="text-[10px] bg-slate-50">
                  {task.type}
                </Badge>
              </div>
              <CardTitle className="text-sm font-bold text-slate-900">{task.title}</CardTitle>
              <p className="text-xs font-medium text-slate-600">{t('clients')}: {task.clientName}</p>
            </CardHeader>

            <CardContent className="p-4 pt-2 space-y-3 text-xs text-slate-600">
              <div className="space-y-1 bg-slate-50 p-2 rounded border border-slate-100">
                <p className="flex items-center gap-1.5 text-slate-700">
                  <Clock className="h-3.5 w-3.5 text-slate-400" />
                  <span>{task.scheduledDate} at {task.scheduledTime}</span>
                </p>
                <p className="flex items-center gap-1.5 text-slate-700">
                  <User className="h-3.5 w-3.5 text-slate-400" />
                  <span>{t('assignedTech')}: <strong>{task.technicianName}</strong></span>
                </p>
                <p className="flex items-start gap-1.5 text-slate-500">
                  <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span className="truncate">{task.address}</span>
                </p>
              </div>

              {task.notes && (
                <p className="italic text-slate-500">"{task.notes}"</p>
              )}

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 uppercase font-bold">Status</span>
                <Select value={task.status} onValueChange={(val: ScheduleTask['status']) => updateTaskStatus(task.id, val)}>
                  <SelectTrigger className="h-7 text-xs w-32 bg-white"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="scheduled">{t('scheduled')}</SelectItem>
                    <SelectItem value="in_progress">{t('inProgress')}</SelectItem>
                    <SelectItem value="completed">{t('completed')}</SelectItem>
                    <SelectItem value="cancelled">{t('cancelled')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default SchedulePage;