import React from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  FolderKanban, 
  Package, 
  Receipt, 
  Calendar, 
  Plus, 
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { clients, projects, inventory, invoices, tasks, t, formatMoney } = useApp();

  // Metrics calculation
  const totalRevenue = invoices
    .filter(i => i.status === 'paid' || i.status === 'partially_paid')
    .reduce((sum, i) => sum + i.totalAmount, 0);

  const ongoingProjects = projects.filter(p => p.status === 'ongoing').length;
  const pendingProjects = projects.filter(p => p.status === 'pending').length;
  const completedProjects = projects.filter(p => p.status === 'completed').length;
  
  const lowStockItems = inventory.filter(i => i.quantity <= i.minThreshold);
  const scheduledTasks = tasks.filter(t => t.status === 'scheduled' || t.status === 'in_progress');

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-900 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <Badge className="bg-cyan-500/20 text-cyan-300 border-cyan-400/30 mb-2">{t('operationalHub')}</Badge>
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">{t('dashboardTitle')}</h1>
          <p className="text-slate-300 text-sm mt-1 max-w-xl">
            {t('dashboardDesc')}
          </p>
        </div>
        <div className="flex gap-3">
          <Link to="/projects">
            <Button className="bg-blue-600 hover:bg-blue-500 text-white font-medium shadow-md shadow-blue-600/30">
              <Plus className="mr-1.5 h-4 w-4 rtl:ml-1.5 rtl:mr-0" /> {t('newProject')}
            </Button>
          </Link>
          <Link to="/invoices">
            <Button variant="outline" className="border-slate-700 text-slate-200 bg-slate-800/60 hover:bg-slate-800">
              <Receipt className="mr-1.5 h-4 w-4 text-cyan-400 rtl:ml-1.5 rtl:mr-0" /> {t('createInvoice')}
            </Button>
          </Link>
        </div>
      </div>

      {/* Quick Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="shadow-sm border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t('totalRevenue')}</CardTitle>
            <div className="h-8 w-8 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600">
              <TrendingUp className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-slate-800">{formatMoney(totalRevenue)}</div>
            <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
              <span className="text-emerald-600 font-medium">+{invoices.length} {t('invoices')}</span>
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t('activeProjects')}</CardTitle>
            <div className="h-8 w-8 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600">
              <FolderKanban className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-800">{ongoingProjects}</div>
            <div className="flex gap-2 text-xs text-slate-500 mt-1">
              <span className="text-amber-600 font-medium">{pendingProjects} {t('pending')}</span>
              <span>•</span>
              <span className="text-emerald-600 font-medium">{completedProjects} {t('done')}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t('lowStockEquipment')}</CardTitle>
            <div className="h-8 w-8 rounded-lg bg-amber-100 flex items-center justify-center text-amber-600">
              <Package className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-800">{lowStockItems.length}</div>
            <p className="text-xs text-amber-600 font-medium mt-1">
              {lowStockItems.length > 0 ? t('requiresReorder') : t('allHardwareStocked')}
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t('activeClientsCount')}</CardTitle>
            <div className="h-8 w-8 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600">
              <Users className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-800">{clients.length}</div>
            <p className="text-xs text-slate-500 mt-1">{t('contractedOrgs')}</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Operational Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Ongoing Projects & Low Stock Alert */}
        <div className="lg:col-span-2 space-y-6">
          {/* Projects Pipeline Preview */}
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base font-bold text-slate-800">{t('currentProjects')}</CardTitle>
                <CardDescription>{t('liveDeploymentStatus')}</CardDescription>
              </div>
              <Link to="/projects">
                <Button variant="ghost" size="sm" className="text-blue-600 text-xs font-semibold">
                  {t('viewAll')} <ArrowUpRight className="ml-1 h-3.5 w-3.5 rtl:mr-1 rtl:ml-0" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {projects.slice(0, 3).map((project) => (
                  <div key={project.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-white hover:border-slate-300 transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-slate-800">{project.title}</span>
                        <Badge variant="outline" className={`capitalize text-[10px] font-bold ${
                          project.status === 'ongoing' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                          project.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                          'bg-amber-50 text-amber-700 border-amber-200'
                        }`}>
                          {project.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-500">{t('clients')}: <span className="font-medium text-slate-700">{project.clientName}</span> • {t('leadTechnician')}: <span className="font-medium text-slate-700">{project.technician}</span></p>
                    </div>
                    <div className="text-right flex sm:flex-col justify-between w-full sm:w-auto items-center sm:items-end">
                      <span className="text-xs font-bold text-slate-700">{formatMoney(project.estimatedBudget)}</span>
                      <span className="text-[11px] text-slate-400">{project.endDate || 'TBD'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Low Stock Equipment Table Card */}
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                <div>
                  <CardTitle className="text-base font-bold text-slate-800">{t('lowInventoryWarnings')}</CardTitle>
                  <CardDescription>{t('belowThreshold')}</CardDescription>
                </div>
              </div>
              <Link to="/inventory">
                <Button variant="ghost" size="sm" className="text-blue-600 text-xs font-semibold">
                  {t('viewAll')} <ArrowUpRight className="ml-1 h-3.5 w-3.5 rtl:mr-1 rtl:ml-0" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {lowStockItems.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">
                  <CheckCircle2 className="h-8 w-8 text-emerald-500 mx-auto mb-2" />
                  {t('allStockedMsg')}
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {lowStockItems.map((item) => (
                    <div key={item.id} className="py-3 flex items-center justify-between">
                      <div>
                        <p className="text-xs font-semibold text-slate-800">{item.name}</p>
                        <p className="text-[11px] text-slate-400">SKU: {item.sku} • {t('storage')}: {item.location}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-xs font-bold text-amber-600">{item.quantity}</span>
                          <p className="text-[10px] text-slate-400">{t('reorderAt')}: {item.minThreshold}</p>
                        </div>
                        <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-300 text-[10px]">
                          {t('reorderRequired')}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Upcoming Schedule & Tech Appointments */}
        <div className="space-y-6">
          <Card className="border-slate-200 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-600" />
                <div>
                  <CardTitle className="text-base font-bold text-slate-800">{t('technicianSchedule')}</CardTitle>
                  <CardDescription>{t('upcomingVisits')}</CardDescription>
                </div>
              </div>
              <Link to="/schedule">
                <Button size="sm" variant="outline" className="text-xs">{t('scheduleBtn')}</Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {scheduledTasks.map((tItem) => (
                  <div key={tItem.id} className="p-3 rounded-lg border border-slate-100 bg-white shadow-2xs space-y-2">
                    <div className="flex items-center justify-between">
                      <Badge className={`text-[10px] uppercase tracking-wider font-bold ${
                        tItem.priority === 'urgent' ? 'bg-red-500 text-white' :
                        tItem.priority === 'high' ? 'bg-amber-500 text-white' :
                        'bg-slate-200 text-slate-700'
                      }`}>
                        {t(tItem.priority as any) || tItem.priority}
                      </Badge>
                      <span className="text-[11px] text-slate-500 flex items-center gap-1 font-medium">
                        <Clock className="h-3 w-3 text-slate-400" /> {tItem.scheduledDate} ({tItem.scheduledTime})
                      </span>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">{tItem.title}</h4>
                      <p className="text-[11px] text-slate-500">{tItem.clientName}</p>
                    </div>
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
                      <span>{t('leadTechnician')}: <strong className="text-slate-800">{tItem.technicianName}</strong></span>
                      <span className="capitalize font-semibold text-blue-600">{tItem.type}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;