import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, User, Camera, Trash2, Coins } from 'lucide-react';
import { ProjectStatus, ProjectType } from '@/types';

const ProjectsPage = () => {
  const { projects, clients, inventory, addProject, updateProjectStatus, deleteProject, currentRole, t, formatMoney } = useApp();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // New project state
  const [formData, setFormData] = useState({
    title: '',
    clientId: '',
    type: 'camera_installation' as ProjectType,
    status: 'pending' as ProjectStatus,
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    technician: '',
    estimatedBudget: 150000,
    description: '',
    address: '',
    selectedDeviceId: '',
    deviceQty: 1,
  });

  const [allocatedDevices, setAllocatedDevices] = useState<{ deviceId: string; deviceName: string; qty: number }[]>([]);

  const handleAddDevice = () => {
    if (!formData.selectedDeviceId) return;
    const item = inventory.find(i => i.id === formData.selectedDeviceId);
    if (!item) return;

    setAllocatedDevices(prev => [
      ...prev,
      { deviceId: item.id, deviceName: item.name, qty: formData.deviceQty }
    ]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find(c => c.id === formData.clientId);
    if (!formData.title || !client) return;

    addProject({
      title: formData.title,
      clientId: client.id,
      clientName: client.name,
      type: formData.type,
      status: formData.status,
      startDate: formData.startDate,
      endDate: formData.endDate,
      technician: formData.technician || 'Unassigned Tech',
      estimatedBudget: Number(formData.estimatedBudget),
      devicesAllocated: allocatedDevices,
      description: formData.description,
      address: formData.address || client.address,
    });

    setFormData({
      title: '',
      clientId: '',
      type: 'camera_installation',
      status: 'pending',
      startDate: new Date().toISOString().split('T')[0],
      endDate: '',
      technician: '',
      estimatedBudget: 150000,
      description: '',
      address: '',
      selectedDeviceId: '',
      deviceQty: 1,
    });
    setAllocatedDevices([]);
    setIsDialogOpen(false);
  };

  const statusColumns: { key: ProjectStatus; title: string; color: string }[] = [
    { key: 'pending', title: t('pendingCol'), color: 'border-amber-400 bg-amber-50/50' },
    { key: 'ongoing', title: t('ongoingCol'), color: 'border-blue-500 bg-blue-50/50' },
    { key: 'completed', title: t('completedCol'), color: 'border-emerald-500 bg-emerald-50/50' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-900">{t('projectOperations')}</h1>
          <p className="text-xs text-slate-500">{t('projectOpsDesc')}</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-500 text-white font-medium">
              <Plus className="mr-1.5 h-4 w-4 rtl:ml-1.5 rtl:mr-0" /> {t('registerNewProject')}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{t('registerProjectTitle')}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-2">
              <div className="space-y-1">
                <Label className="text-xs">{t('projectTitle')} *</Label>
                <Input 
                  required 
                  placeholder="e.g. CCTV Installation Phase 1" 
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('selectClient')} *</Label>
                  <Select 
                    value={formData.clientId} 
                    onValueChange={(val) => setFormData({ ...formData, clientId: val })}
                  >
                    <SelectTrigger><SelectValue placeholder="..." /></SelectTrigger>
                    <SelectContent>
                      {clients.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs">{t('projectCategory')}</Label>
                  <Select 
                    value={formData.type} 
                    onValueChange={(val: ProjectType) => setFormData({ ...formData, type: val })}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="camera_installation">{t('cameraInstallation')}</SelectItem>
                      <SelectItem value="maintenance">{t('maintenanceService')}</SelectItem>
                      <SelectItem value="system_upgrade">{t('systemUpgrade')}</SelectItem>
                      <SelectItem value="network_setup">{t('networkSetup')}</SelectItem>
                      <SelectItem value="access_control">{t('accessControl')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('leadTechnician')}</Label>
                  <Input 
                    placeholder="Technician name" 
                    value={formData.technician}
                    onChange={e => setFormData({ ...formData, technician: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('budget')}</Label>
                  <Input 
                    type="number" 
                    value={formData.estimatedBudget}
                    onChange={e => setFormData({ ...formData, estimatedBudget: Number(e.target.value) })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">{t('startDate')}</Label>
                  <Input 
                    type="date" 
                    value={formData.startDate}
                    onChange={e => setFormData({ ...formData, startDate: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">{t('expectedCompletion')}</Label>
                  <Input 
                    type="date" 
                    value={formData.endDate}
                    onChange={e => setFormData({ ...formData, endDate: e.target.value })}
                  />
                </div>
              </div>

              {/* Hardware Allocation Section */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                <Label className="text-xs font-bold text-slate-700">{t('allocateHardware')}</Label>
                <div className="flex gap-2">
                  <Select 
                    value={formData.selectedDeviceId} 
                    onValueChange={(val) => setFormData({ ...formData, selectedDeviceId: val })}
                  >
                    <SelectTrigger className="flex-1 text-xs bg-white"><SelectValue placeholder="..." /></SelectTrigger>
                    <SelectContent>
                      {inventory.map(item => (
                        <SelectItem key={item.id} value={item.id}>{item.name} ({item.quantity})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input 
                    type="number" 
                    min={1}
                    className="w-16 bg-white text-xs" 
                    value={formData.deviceQty}
                    onChange={e => setFormData({ ...formData, deviceQty: Number(e.target.value) })}
                  />
                  <Button type="button" size="sm" onClick={handleAddDevice} className="bg-slate-800 text-xs">{t('add')}</Button>
                </div>

                {allocatedDevices.length > 0 && (
                  <div className="space-y-1 pt-1">
                    {allocatedDevices.map((d, i) => (
                      <div key={i} className="flex justify-between text-xs bg-white p-1.5 rounded border border-slate-200">
                        <span>{d.deviceName}</span>
                        <span className="font-bold">x{d.qty}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <Label className="text-xs">{t('projectScope')}</Label>
                <Textarea 
                  rows={3} 
                  placeholder="..."
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>{t('cancel')}</Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-500">{t('createProjectBtn')}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Kanban Pipeline Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {statusColumns.map((col) => {
          const colProjects = projects.filter(p => p.status === col.key);
          return (
            <div key={col.key} className="space-y-3">
              <div className={`p-3 rounded-lg border-l-4 rtl:border-r-4 rtl:border-l-0 ${col.color} bg-white border border-slate-200 shadow-2xs flex justify-between items-center`}>
                <h3 className="font-bold text-slate-800 text-sm">{col.title}</h3>
                <Badge variant="secondary" className="font-bold">{colProjects.length}</Badge>
              </div>

              <div className="space-y-4">
                {colProjects.map((project) => (
                  <Card key={project.id} className="border-slate-200 hover:shadow-md transition-shadow">
                    <CardHeader className="p-4 pb-2 space-y-1">
                      <div className="flex justify-between items-start gap-2">
                        <Badge variant="outline" className="text-[10px] capitalize bg-slate-50 text-slate-700 font-semibold">
                          {project.type.replace('_', ' ')}
                        </Badge>
                        <Select 
                          value={project.status} 
                          onValueChange={(status: ProjectStatus) => updateProjectStatus(project.id, status)}
                        >
                          <SelectTrigger className="h-6 text-[10px] w-28 bg-white"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">{t('pending')}</SelectItem>
                            <SelectItem value="ongoing">{t('inProgress')}</SelectItem>
                            <SelectItem value="completed">{t('completed')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <CardTitle className="text-sm font-bold text-slate-900 leading-snug">{project.title}</CardTitle>
                      <CardDescription className="text-xs text-slate-500 font-medium">{t('clients')}: {project.clientName}</CardDescription>
                    </CardHeader>

                    <CardContent className="p-4 pt-2 space-y-3 text-xs text-slate-600">
                      <p className="line-clamp-2 text-slate-600 italic bg-slate-50 p-2 rounded border border-slate-100">
                        {project.description}
                      </p>

                      <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-100">
                        <span className="flex items-center gap-1 font-medium text-slate-700">
                          <User className="h-3 w-3 text-slate-400" /> {project.technician}
                        </span>
                        <span className="flex items-center gap-1 font-bold text-slate-800 justify-end">
                          <Coins className="h-3 w-3 text-amber-600" /> {formatMoney(project.estimatedBudget)}
                        </span>
                      </div>

                      {project.devicesAllocated.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1">
                            <Camera className="h-3 w-3 text-cyan-600" /> {t('allocateHardware')}:
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {project.devicesAllocated.map((dev, idx) => (
                              <Badge key={idx} variant="secondary" className="text-[10px] bg-slate-100 text-slate-700 font-medium">
                                {dev.deviceName} x{dev.qty}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {currentRole === 'Admin' && (
                        <div className="pt-2 flex justify-end">
                          <Button size="icon" variant="ghost" className="h-6 w-6 text-red-500 hover:bg-red-50" onClick={() => deleteProject(project.id)}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProjectsPage;