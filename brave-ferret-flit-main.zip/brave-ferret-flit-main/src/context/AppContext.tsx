import React, { createContext, useContext, useState, useEffect } from 'react';
import { Client, Project, InventoryItem, Invoice, ScheduleTask, RoleName, RolePermission, Language, Currency } from '@/types';
import { translations } from '@/utils/translations';
import { formatCurrency } from '@/utils/formatters';
import { toast } from 'sonner';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  currency: Currency;
  setCurrency: (curr: Currency) => void;
  t: (key: keyof typeof translations.en) => string;
  formatMoney: (amount: number) => string;
  clients: Client[];
  projects: Project[];
  inventory: InventoryItem[];
  invoices: Invoice[];
  tasks: ScheduleTask[];
  permissions: RolePermission[];
  currentRole: RoleName;
  setCurrentRole: (role: RoleName) => void;
  
  // Client actions
  addClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  updateClient: (id: string, client: Partial<Client>) => void;
  deleteClient: (id: string) => void;

  // Project actions
  addProject: (project: Omit<Project, 'id'>) => void;
  updateProjectStatus: (id: string, status: Project['status']) => void;
  deleteProject: (id: string) => void;

  // Inventory actions
  addInventoryItem: (item: Omit<InventoryItem, 'id'>) => void;
  adjustStock: (id: string, delta: number) => void;

  // Invoice actions
  addInvoice: (invoice: Omit<Invoice, 'id' | 'invoiceNumber'>) => void;
  updateInvoiceStatus: (id: string, status: Invoice['status']) => void;

  // Task actions
  addTask: (task: Omit<ScheduleTask, 'id'>) => void;
  updateTaskStatus: (id: string, status: ScheduleTask['status']) => void;

  // Permission actions
  updatePermissions: (role: RoleName, field: keyof Omit<RolePermission, 'role'>, value: boolean) => void;
}

const initialClients: Client[] = [
  {
    id: 'c1',
    name: 'Metropolis Bank & Trust',
    companyName: 'Metropolis Financial Corp',
    email: 'sec-ops@metropolisbank.com',
    phone: '+20 100 234 5678',
    address: '100 Financial Center, Tower A, Cairo, Egypt',
    contractType: 'VIP Enterprise',
    contractEndDate: '2026-12-31',
    notes: 'Requires 4K PTZ cameras with cloud auto-backup and 24/7 monitoring.',
    createdAt: '2024-01-15',
  },
  {
    id: 'c2',
    name: 'Apex Logistics Hub',
    companyName: 'Apex Shipping Solutions',
    email: 'facilities@apexlogistics.io',
    phone: '+20 122 987 6543',
    address: '45 Freight Highway, Sector 4, Alexandria, Egypt',
    contractType: 'Annual Maintenance',
    contractEndDate: '2025-08-20',
    notes: 'Perimeter thermal camera setup and license plate recognition system.',
    createdAt: '2024-03-02',
  },
  {
    id: 'c3',
    name: 'Horizon Shopping Plaza',
    companyName: 'Horizon Real Estate Group',
    email: 'management@horizonplaza.com',
    phone: '+20 111 345 6789',
    address: '880 Corniche Blvd, Giza, Egypt',
    contractType: 'Standard',
    contractEndDate: '2025-11-10',
    notes: 'Indoor dome cameras with AI people-counting features.',
    createdAt: '2024-05-19',
  },
];

const initialProjects: Project[] = [
  {
    id: 'p1',
    title: 'Bank HQ Perimeter 4K Camera Upgrade',
    clientId: 'c1',
    clientName: 'Metropolis Bank & Trust',
    type: 'system_upgrade',
    status: 'ongoing',
    startDate: '2025-02-01',
    endDate: '2025-03-15',
    technician: 'Marcus Vance',
    estimatedBudget: 450000,
    devicesAllocated: [
      { deviceId: 'i1', deviceName: '4K Ultra-HD Dome Camera', qty: 12 },
      { deviceId: 'i2', deviceName: '32-Channel NVR Server (16TB)', qty: 2 },
    ],
    description: 'Upgrading existing legacy analog cameras to 4K IP security cameras with facial recognition.',
    address: '100 Financial Center, Tower A, Cairo, Egypt',
  },
  {
    id: 'p2',
    title: 'Warehouse Gate LPR Installation',
    clientId: 'c2',
    clientName: 'Apex Logistics Hub',
    type: 'camera_installation',
    status: 'pending',
    startDate: '2025-03-05',
    endDate: '2025-03-20',
    technician: 'David Miller',
    estimatedBudget: 280000,
    devicesAllocated: [
      { deviceId: 'i5', deviceName: 'ANPR License Plate Recognition Camera', qty: 4 },
      { deviceId: 'i3', deviceName: 'Cat6 Outdoor Shielded Cable (100m)', qty: 5 },
    ],
    description: 'Installing license plate scanner cameras at all entry and exit gates connected to truck dispatch database.',
    address: '45 Freight Highway, Sector 4, Alexandria, Egypt',
  },
  {
    id: 'p3',
    title: 'Quarterly Maintenance & Cable Check',
    clientId: 'c3',
    clientName: 'Horizon Shopping Plaza',
    type: 'maintenance',
    status: 'completed',
    startDate: '2025-01-10',
    endDate: '2025-01-12',
    technician: 'Elena Rostova',
    estimatedBudget: 68000,
    devicesAllocated: [
      { deviceId: 'i6', deviceName: '12V 5A Power Supply Adapter', qty: 6 },
    ],
    description: 'Routine lens cleaning, firmware patch update, and replacement of degraded power adapters.',
    address: '880 Corniche Blvd, Giza, Egypt',
  },
];

const initialInventory: InventoryItem[] = [
  {
    id: 'i1',
    name: '4K Ultra-HD Dome Camera',
    sku: 'CAM-4K-DOME-01',
    category: 'cameras',
    quantity: 14,
    minThreshold: 15,
    unitPrice: 8500,
    supplier: 'HikVision Tech Direct',
    location: 'Shelf A-3',
  },
  {
    id: 'i2',
    name: '32-Channel NVR Server (16TB)',
    sku: 'NVR-32CH-16TB',
    category: 'dvrs_nvrs',
    quantity: 4,
    minThreshold: 3,
    unitPrice: 45000,
    supplier: 'Dahua Security Corp',
    location: 'Rack B-1',
  },
  {
    id: 'i3',
    name: 'Cat6 Outdoor Shielded Cable (100m)',
    sku: 'CAB-CAT6-OUT-100',
    category: 'cables',
    quantity: 28,
    minThreshold: 10,
    unitPrice: 2400,
    supplier: 'CableCraft Direct',
    location: 'Bay C-12',
  },
  {
    id: 'i4',
    name: 'Thermal PIR Motion Sensor',
    sku: 'SNS-PIR-THERM',
    category: 'sensors',
    quantity: 8,
    minThreshold: 12,
    unitPrice: 3500,
    supplier: 'Bosch Security Systems',
    location: 'Bin S-4',
  },
  {
    id: 'i5',
    name: 'ANPR License Plate Camera',
    sku: 'CAM-LPR-PRO-200',
    category: 'cameras',
    quantity: 6,
    minThreshold: 5,
    unitPrice: 21000,
    supplier: 'Axis Communications',
    location: 'Shelf A-5',
  },
  {
    id: 'i6',
    name: '12V 5A Multi-Port Power Box',
    sku: 'PWR-12V5A-BOX',
    category: 'power',
    quantity: 19,
    minThreshold: 8,
    unitPrice: 1400,
    supplier: 'PowerGuard Elec',
    location: 'Shelf E-2',
  },
];

const initialInvoices: Invoice[] = [
  {
    id: 'inv1',
    invoiceNumber: 'INV-2025-001',
    clientId: 'c1',
    clientName: 'Metropolis Bank & Trust',
    projectId: 'p1',
    issueDate: '2025-02-10',
    dueDate: '2025-03-10',
    items: [
      { description: '4K Ultra-HD Dome Camera (12 units)', quantity: 12, unitPrice: 8500, total: 102000 },
      { description: '32-Channel NVR Server 16TB (2 units)', quantity: 2, unitPrice: 45000, total: 90000 },
      { description: 'Installation & Network Configuration Labor', quantity: 40, unitPrice: 3000, total: 120000 },
    ],
    subtotal: 312000,
    tax: 24960,
    totalAmount: 336960,
    status: 'partially_paid',
  },
  {
    id: 'inv2',
    invoiceNumber: 'INV-2025-002',
    clientId: 'c3',
    clientName: 'Horizon Shopping Plaza',
    projectId: 'p3',
    issueDate: '2025-01-15',
    dueDate: '2025-02-15',
    items: [
      { description: 'Quarterly Security Maintenance Package', quantity: 1, unitPrice: 55000, total: 55000 },
      { description: 'Power Box replacement parts', quantity: 6, unitPrice: 1400, total: 8400 },
    ],
    subtotal: 63400,
    tax: 5072,
    totalAmount: 68472,
    status: 'paid',
  },
  {
    id: 'inv3',
    invoiceNumber: 'INV-2025-003',
    clientId: 'c2',
    clientName: 'Apex Logistics Hub',
    projectId: 'p2',
    issueDate: '2025-01-20',
    dueDate: '2025-02-20',
    items: [
      { description: 'LPR System Down Payment (50%)', quantity: 1, unitPrice: 140000, total: 140000 },
    ],
    subtotal: 140000,
    tax: 11200,
    totalAmount: 151200,
    status: 'overdue',
  },
];

const initialTasks: ScheduleTask[] = [
  {
    id: 't1',
    title: 'Emergency Camera Feed Repair',
    clientId: 'c1',
    clientName: 'Metropolis Bank & Trust',
    technicianName: 'Marcus Vance',
    scheduledDate: '2025-02-28',
    scheduledTime: '09:00 AM',
    type: 'Emergency Repair',
    status: 'in_progress',
    priority: 'urgent',
    notes: 'Camera #4 on north perimeter wall losing signal intermittently.',
    address: '100 Financial Center, Tower A, Cairo, Egypt',
  },
  {
    id: 't2',
    title: 'Gate LPR System Wiring Setup',
    clientId: 'c2',
    clientName: 'Apex Logistics Hub',
    technicianName: 'David Miller',
    scheduledDate: '2025-03-05',
    scheduledTime: '10:30 AM',
    type: 'Installation',
    status: 'scheduled',
    priority: 'high',
    notes: 'Run outdoor Cat6 cables and test automatic gate barrier connection.',
    address: '45 Freight Highway, Sector 4, Alexandria, Egypt',
  },
  {
    id: 't3',
    title: 'Semi-Annual System Calibration',
    clientId: 'c3',
    clientName: 'Horizon Shopping Plaza',
    technicianName: 'Elena Rostova',
    scheduledDate: '2025-03-12',
    scheduledTime: '02:00 PM',
    type: 'Periodic Maintenance',
    status: 'scheduled',
    priority: 'medium',
    notes: 'Clean glass domes, adjust PTZ presets, test backup power generator switch.',
    address: '880 Corniche Blvd, Giza, Egypt',
  },
];

const initialPermissions: RolePermission[] = [
  {
    role: 'Admin',
    manageClients: true,
    manageProjects: true,
    manageInventory: true,
    manageInvoices: true,
    manageSchedule: true,
    viewReports: true,
    managePermissions: true,
  },
  {
    role: 'Project Manager',
    manageClients: true,
    manageProjects: true,
    manageInventory: true,
    manageInvoices: false,
    manageSchedule: true,
    viewReports: true,
    managePermissions: false,
  },
  {
    role: 'Field Technician',
    manageClients: false,
    manageProjects: true,
    manageInventory: true,
    manageInvoices: false,
    manageSchedule: true,
    viewReports: false,
    managePermissions: false,
  },
  {
    role: 'Billing Clerk',
    manageClients: true,
    manageProjects: false,
    manageInventory: false,
    manageInvoices: true,
    manageSchedule: false,
    viewReports: true,
    managePermissions: false,
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');
  const [currency, setCurrency] = useState<Currency>('EGP');
  const [clients, setClients] = useState<Client[]>(initialClients);
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [inventory, setInventory] = useState<InventoryItem[]>(initialInventory);
  const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);
  const [tasks, setTasks] = useState<ScheduleTask[]>(initialTasks);
  const [permissions, setPermissions] = useState<RolePermission[]>(initialPermissions);
  const [currentRole, setCurrentRole] = useState<RoleName>('Admin');

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: keyof typeof translations.en) => {
    return translations[language][key] || translations['en'][key] || key;
  };

  const formatMoney = (amount: number) => {
    return formatCurrency(amount, language, currency);
  };

  // Client actions
  const addClient = (data: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...data,
      id: `c_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setClients(prev => [newClient, ...prev]);
    toast.success(language === 'ar' ? `تم إضافة العميل ${data.name} بنجاح!` : `Client ${data.name} created successfully!`);
  };

  const updateClient = (id: string, data: Partial<Client>) => {
    setClients(prev => prev.map(c => c.id === id ? { ...c, ...data } : c));
    toast.success(language === 'ar' ? 'تم تحديث بيانات العميل' : 'Client updated successfully');
  };

  const deleteClient = (id: string) => {
    setClients(prev => prev.filter(c => c.id !== id));
    toast.info(language === 'ar' ? 'تم حذف العميل' : 'Client removed');
  };

  // Project actions
  const addProject = (data: Omit<Project, 'id'>) => {
    const newProj: Project = {
      ...data,
      id: `p_${Date.now()}`,
    };
    setProjects(prev => [newProj, ...prev]);
    toast.success(language === 'ar' ? `تم تسجيل المشروع "${data.title}"` : `Project "${data.title}" registered!`);
  };

  const updateProjectStatus = (id: string, status: Project['status']) => {
    setProjects(prev => prev.map(p => p.id === id ? { ...p, status } : p));
    toast.success(language === 'ar' ? 'تم تحديث حالة المشروع' : `Project status updated to ${status.replace('_', ' ')}`);
  };

  const deleteProject = (id: string) => {
    setProjects(prev => prev.filter(p => p.id !== id));
    toast.info(language === 'ar' ? 'تم حذف المشروع' : 'Project deleted');
  };

  // Inventory actions
  const addInventoryItem = (data: Omit<InventoryItem, 'id'>) => {
    const newItem: InventoryItem = {
      ...data,
      id: `i_${Date.now()}`,
    };
    setInventory(prev => [newItem, ...prev]);
    toast.success(language === 'ar' ? `تم إضافة ${data.name} إلى المخزن!` : `Added ${data.name} to inventory!`);
  };

  const adjustStock = (id: string, delta: number) => {
    setInventory(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(0, item.quantity + delta);
        if (newQty <= item.minThreshold) {
          toast.warning(language === 'ar' ? `تنبيه نقص المخزون لـ ${item.name}! (المتبقي ${newQty})` : `Low stock warning for ${item.name}! (${newQty} remaining)`);
        } else {
          toast.success(language === 'ar' ? `تم تحديث كمية ${item.name} إلى ${newQty}` : `Updated ${item.name} quantity to ${newQty}`);
        }
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  // Invoice actions
  const addInvoice = (data: Omit<Invoice, 'id' | 'invoiceNumber'>) => {
    const num = `INV-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
    const newInv: Invoice = {
      ...data,
      id: `inv_${Date.now()}`,
      invoiceNumber: num,
    };
    setInvoices(prev => [newInv, ...prev]);
    toast.success(language === 'ar' ? `تم إصدار الفاتورة ${num} بنجاح!` : `Invoice ${num} generated successfully!`);
  };

  const updateInvoiceStatus = (id: string, status: Invoice['status']) => {
    setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, status } : inv));
    toast.success(language === 'ar' ? 'تم تغيير حالة الفاتورة' : `Invoice payment status changed to ${status}`);
  };

  // Task actions
  const addTask = (data: Omit<ScheduleTask, 'id'>) => {
    const newTask: ScheduleTask = {
      ...data,
      id: `t_${Date.now()}`,
    };
    setTasks(prev => [newTask, ...prev]);
    toast.success(language === 'ar' ? `تم جدولة الموعد لـ ${data.clientName}` : `Scheduled visit for ${data.clientName}`);
  };

  const updateTaskStatus = (id: string, status: ScheduleTask['status']) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status } : t));
    toast.success(language === 'ar' ? 'تم تحديث حالة الموعد' : `Task status updated to ${status.replace('_', ' ')}`);
  };

  // Permissions
  const updatePermissions = (role: RoleName, field: keyof Omit<RolePermission, 'role'>, value: boolean) => {
    setPermissions(prev => prev.map(p => p.role === role ? { ...p, [field]: value } : p));
    toast.success(language === 'ar' ? `تم تحديث الصلاحية لـ ${role}` : `Updated permission [${field}] for role ${role}`);
  };

  return (
    <AppContext.Provider value={{
      language,
      setLanguage,
      currency,
      setCurrency,
      t,
      formatMoney,
      clients,
      projects,
      inventory,
      invoices,
      tasks,
      permissions,
      currentRole,
      setCurrentRole,
      addClient,
      updateClient,
      deleteClient,
      addProject,
      updateProjectStatus,
      deleteProject,
      addInventoryItem,
      adjustStock,
      addInvoice,
      updateInvoiceStatus,
      addTask,
      updateTaskStatus,
      updatePermissions,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};