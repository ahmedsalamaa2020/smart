export type Language = 'en' | 'ar';
export type Currency = 'EGP' | 'USD';
export type ProjectStatus = 'pending' | 'ongoing' | 'completed' | 'on_hold';
export type ProjectType = 'camera_installation' | 'maintenance' | 'system_upgrade' | 'network_setup' | 'access_control';
export type PaymentStatus = 'paid' | 'pending' | 'overdue' | 'partially_paid';
export type InventoryCategory = 'cameras' | 'dvrs_nvrs' | 'cables' | 'sensors' | 'power' | 'accessories';
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';
export type RoleName = 'Admin' | 'Project Manager' | 'Field Technician' | 'Billing Clerk';

export interface Client {
  id: string;
  name: string;
  companyName?: string;
  email: string;
  phone: string;
  address: string;
  contractType: 'Annual Maintenance' | 'Standard' | 'VIP Enterprise' | 'On-Demand';
  contractEndDate?: string;
  notes: string;
  createdAt: string;
}

export interface Project {
  id: string;
  title: string;
  clientId: string;
  clientName: string;
  type: ProjectType;
  status: ProjectStatus;
  startDate: string;
  endDate?: string;
  technician: string;
  estimatedBudget: number;
  devicesAllocated: { deviceId: string; deviceName: string; qty: number }[];
  description: string;
  address: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  category: InventoryCategory;
  quantity: number;
  minThreshold: number;
  unitPrice: number;
  supplier: string;
  location: string;
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  clientName: string;
  projectId?: string;
  issueDate: string;
  dueDate: string;
  items: InvoiceItem[];
  subtotal: number;
  tax: number;
  totalAmount: number;
  status: PaymentStatus;
}

export interface ScheduleTask {
  id: string;
  title: string;
  clientId: string;
  clientName: string;
  projectId?: string;
  technicianName: string;
  scheduledDate: string;
  scheduledTime: string;
  type: 'Installation' | 'Periodic Maintenance' | 'Emergency Repair' | 'Site Inspection';
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
  priority: TaskPriority;
  notes: string;
  address: string;
}

export interface RolePermission {
  role: RoleName;
  manageClients: boolean;
  manageProjects: boolean;
  manageInventory: boolean;
  manageInvoices: boolean;
  manageSchedule: boolean;
  viewReports: boolean;
  managePermissions: boolean;
}